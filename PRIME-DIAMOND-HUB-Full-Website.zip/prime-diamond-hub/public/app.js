const $ = s => document.querySelector(s);
let shop = {products:[],offers:[],whatsapp:'94756649083'}, me=null, authMode='login', selectedProduct=null;
const money = n => 'Rs. ' + Number(n).toLocaleString('en-LK');
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800)}
async function api(url,options={}){const r=await fetch(url,options);let d={};try{d=await r.json()}catch{}if(!r.ok)throw new Error(d.error||'Something went wrong.');return d}
function openModal(id){$('#'+id).classList.add('show')};function closeModal(id){$('#'+id).classList.remove('show')}
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>closeModal(b.dataset.close)));
document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')}));
function renderProducts(){
 const diamonds=shop.products.filter(p=>p.category==='diamond'),members=shop.products.filter(p=>p.category==='membership');
 $('#diamondGrid').innerHTML=diamonds.map(p=>card(p,false)).join('')||'<div class="empty">No diamond packages available.</div>';
 $('#membershipGrid').innerHTML=members.map(p=>card(p,true)).join('')||'<div class="empty">No membership packages available.</div>';
 document.querySelectorAll('[data-buy]').forEach(b=>b.addEventListener('click',()=>startOrder(Number(b.dataset.buy))));
}
function card(p,isMember){return `<article class="product ${isMember?'membership':''}"><div class="product-top"><span class="gem-icon">${isMember?'♛':'◆'}</span><span class="section-note">${isMember?'MEMBERSHIP':'DIAMONDS'}</span></div><h3>${escapeHtml(p.name)}</h3><div class="price">${money(p.price)}</div><button class="btn btn-primary" data-buy="${p.id}">Order package →</button></article>`}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function loadShop(){shop=await api('/api/shop');renderProducts();$('#offersGrid').innerHTML=shop.offers.length?shop.offers.map(o=>`<article class="offer"><h3>${escapeHtml(o.title)}</h3><p>${escapeHtml(o.description)}</p></article>`).join(''):'<div class="empty">New offers will appear here.</div>';const num=shop.whatsapp.startsWith('94')?shop.whatsapp:'94'+shop.whatsapp.replace(/^0/,'');$('#waHero').href=`https://wa.me/${num}?text=${encodeURIComponent('Hello PRIME DIAMOND HUB, I need help with a top-up.')}`}
function setAuthTab(mode){authMode=mode;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===mode));$('#nameField').classList.toggle('hidden',mode!=='register');$('#nameField input').required=mode==='register';$('#authSubmit').textContent=mode==='register'?'Create account':'Sign in';$('#authMessage').textContent=''}
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>setAuthTab(b.dataset.tab)));
$('#accountBtn').addEventListener('click',()=>me?showProfile():openModal('authModal'));
$('#authForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);const body=Object.fromEntries(fd.entries());try{const d=await api('/api/auth/'+authMode,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});me=d.user;closeModal('authModal');updateAccountButton();toast('Welcome to PRIME DIAMOND HUB!');if(selectedProduct)openOrderModal(selectedProduct)}catch(err){$('#authMessage').textContent=err.message}});
async function refreshMe(){try{me=(await api('/api/me')).user}catch{me=null}updateAccountButton()}
function updateAccountButton(){$('#accountBtn').textContent=me?`Hi, ${me.name.split(' ')[0]}`:'Sign in'}
async function startOrder(id){selectedProduct=shop.products.find(p=>p.id===id);if(!selectedProduct)return;if(!me){setAuthTab('login');openModal('authModal');toast('Sign in or create an account to order.');return}openOrderModal(selectedProduct)}
function openOrderModal(p){$('#orderTitle').textContent=p.name;$('#orderPrice').textContent='Package price: '+money(p.price);$('#orderForm [name=productId]').value=p.id;$('#pointsHint').textContent=`Your balance: ${me.points} points. 10 points = Rs.20 discount.`;$('#redeemCheck').checked=false;$('#orderMessage').textContent='';openModal('orderModal')}
$('#orderForm').addEventListener('submit',async e=>{e.preventDefault();const fd=new FormData(e.target);try{const d=await api('/api/orders',{method:'POST',body:fd});closeModal('orderModal');toast(`Order #${d.orderId} submitted. Amount due: ${money(d.amountDue)}`);await refreshMe()}catch(err){$('#orderMessage').textContent=err.message}});
async function showProfile(){await refreshMe();if(!me){openModal('authModal');return}$('#profileName').textContent=me.name;$('#profilePoints').textContent=me.points;try{const d=await api('/api/my-orders');$('#myOrders').innerHTML=d.orders.length?d.orders.map(o=>`<div class="order-row"><span><b>#${o.id} · ${escapeHtml(o.product_name)}</b><br><small>${money(o.amount_due)} · ${new Date(o.created_at+'Z').toLocaleDateString()}</small></span><span class="status ${o.status}">${o.status}</span></div>`).join(''):'<div class="empty">You have no orders yet.</div>'}catch(e){$('#myOrders').textContent=e.message}openModal('profileModal')}
$('#logoutBtn').addEventListener('click',async()=>{await api('/api/auth/logout',{method:'POST'});me=null;updateAccountButton();closeModal('profileModal');toast('Signed out.')});
loadShop().catch(e=>toast(e.message));refreshMe();
